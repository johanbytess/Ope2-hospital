import os
from datetime import datetime
from math import factorial
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import Boolean, DateTime, Float, Integer, String, create_engine, desc, select
from sqlalchemy.orm import Session, declarative_base, mapped_column, sessionmaker
from starlette.responses import JSONResponse


BASE_DIR = Path(__file__).resolve().parent
DATABASE_URL = f"sqlite:///{BASE_DIR / 'triage.db'}"
FRONTEND_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "FRONTEND_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5175,http://127.0.0.1:5175",
    ).split(",")
    if origin.strip()
]

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class EscenarioSimulacion(Base):
    __tablename__ = "escenarios_simulacion"

    id = mapped_column(Integer, primary_key=True, index=True)
    c = mapped_column(Integer, nullable=False)
    mu = mapped_column(Float, nullable=False)
    lambda_1 = mapped_column(Float, nullable=False)
    lambda_2 = mapped_column(Float, nullable=False)
    lambda_3 = mapped_column(Float, nullable=False)
    lambda_total = mapped_column(Float, nullable=False)
    rho = mapped_column(Float, nullable=False)
    wq1 = mapped_column(Float, nullable=True)
    wq2 = mapped_column(Float, nullable=True)
    wq3 = mapped_column(Float, nullable=True)
    sistema_saturado = mapped_column(Boolean, nullable=False, default=False)
    error_message = mapped_column(String, nullable=True)
    created_at = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


Base.metadata.create_all(bind=engine)

app = FastAPI(title="Simulador de Triage Hospitalario")

app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SimulacionRequest(BaseModel):
    c: int = Field(..., gt=0, description="Numero de medicos de guardia")
    mu: float = Field(..., gt=0, description="Tasa de atencion por medico")
    lambda_1: float = Field(..., ge=0, description="Llegadas codigo rojo")
    lambda_2: float = Field(..., ge=0, description="Llegadas codigo amarillo")
    lambda_3: float = Field(..., ge=0, description="Llegadas codigo verde")


class SimulacionResponse(BaseModel):
    id: int
    c: int
    mu: float
    lambda_1: float
    lambda_2: float
    lambda_3: float
    lambda_total: float
    rho: float
    wq1: float
    wq2: float
    wq3: float
    sistema_saturado: bool
    created_at: datetime


class EscenarioHistoricoResponse(BaseModel):
    id: int
    c: int
    mu: float
    lambda_1: float
    lambda_2: float
    lambda_3: float
    lambda_total: float
    rho: float
    wq1: Optional[float]
    wq2: Optional[float]
    wq3: Optional[float]
    sistema_saturado: bool
    error_message: Optional[str]
    created_at: datetime


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def calcular_probabilidad_espera(lambda_total: float, mu: float, servidores: int) -> float:
    if lambda_total == 0:
        return 0.0

    trafico = lambda_total / mu
    rho = lambda_total / (servidores * mu)

    sumatoria = sum((trafico**n) / factorial(n) for n in range(servidores))
    termino_final = (trafico**servidores) / factorial(servidores) * (1 / (1 - rho))
    p0 = 1 / (sumatoria + termino_final)
    return termino_final * p0


def calcular_espera_base_mm_c(lambda_total: float, mu: float, servidores: int) -> float:
    if lambda_total == 0:
        return 0.0

    probabilidad_espera = calcular_probabilidad_espera(lambda_total, mu, servidores)
    return probabilidad_espera / ((servidores * mu) - lambda_total)


def calcular_tiempos_prioridad(
    c: int,
    mu: float,
    lambda_1: float,
    lambda_2: float,
    lambda_3: float,
) -> tuple[float, float, float, float]:
    lambda_total = lambda_1 + lambda_2 + lambda_3
    rho = lambda_total / (c * mu)

    if rho >= 1:
        raise ValueError("Sistema Saturado")

    if lambda_total == 0:
        return 0.0, 0.0, 0.0, 0.0

    espera_base = calcular_espera_base_mm_c(lambda_total, mu, c)
    rho_1 = lambda_1 / (c * mu)
    rho_2 = lambda_2 / (c * mu)
    rho_3 = lambda_3 / (c * mu)

    sigma_1 = rho_1
    sigma_2 = rho_1 + rho_2
    sigma_3 = rho_1 + rho_2 + rho_3
    ajuste = 1 - rho

    wq1 = espera_base * ajuste / (1 - sigma_1)
    wq2 = espera_base * ajuste / ((1 - sigma_1) * (1 - sigma_2))
    wq3 = espera_base * ajuste / ((1 - sigma_2) * (1 - sigma_3))

    return wq1, wq2, wq3, rho


def guardar_escenario(
    db: Session,
    payload: SimulacionRequest,
    lambda_total: float,
    rho: float,
    wq1: Optional[float] = None,
    wq2: Optional[float] = None,
    wq3: Optional[float] = None,
    sistema_saturado: bool = False,
    error_message: Optional[str] = None,
) -> EscenarioSimulacion:
    escenario = EscenarioSimulacion(
        c=payload.c,
        mu=payload.mu,
        lambda_1=payload.lambda_1,
        lambda_2=payload.lambda_2,
        lambda_3=payload.lambda_3,
        lambda_total=lambda_total,
        rho=rho,
        wq1=wq1,
        wq2=wq2,
        wq3=wq3,
        sistema_saturado=sistema_saturado,
        error_message=error_message,
    )
    db.add(escenario)
    db.commit()
    db.refresh(escenario)
    return escenario


@app.get("/")
def healthcheck():
    return {"status": "ok", "service": "triage-simulator"}


@app.get("/escenarios", response_model=list[EscenarioHistoricoResponse])
def listar_escenarios(limit: int = 8, db: Session = Depends(get_db)):
    limite_ajustado = min(max(limit, 1), 50)
    consulta = (
        select(EscenarioSimulacion)
        .order_by(desc(EscenarioSimulacion.created_at))
        .limit(limite_ajustado)
    )
    escenarios = db.scalars(consulta).all()

    return [
        EscenarioHistoricoResponse(
            id=escenario.id,
            c=escenario.c,
            mu=escenario.mu,
            lambda_1=escenario.lambda_1,
            lambda_2=escenario.lambda_2,
            lambda_3=escenario.lambda_3,
            lambda_total=escenario.lambda_total,
            rho=escenario.rho,
            wq1=escenario.wq1,
            wq2=escenario.wq2,
            wq3=escenario.wq3,
            sistema_saturado=escenario.sistema_saturado,
            error_message=escenario.error_message,
            created_at=escenario.created_at,
        )
        for escenario in escenarios
    ]


@app.post("/simular", response_model=SimulacionResponse)
def simular(payload: SimulacionRequest, db: Session = Depends(get_db)):
    lambda_total = payload.lambda_1 + payload.lambda_2 + payload.lambda_3
    rho = lambda_total / (payload.c * payload.mu)

    if rho >= 1:
        escenario = guardar_escenario(
            db=db,
            payload=payload,
            lambda_total=lambda_total,
            rho=rho,
            sistema_saturado=True,
            error_message="Sistema Saturado",
        )
        return JSONResponse(
            status_code=400,
            content={
                "id": escenario.id,
                "detail": "Sistema Saturado",
                "rho": rho,
                "sistema_saturado": True,
                "created_at": escenario.created_at.isoformat(),
            },
        )

    wq1, wq2, wq3, rho = calcular_tiempos_prioridad(
        c=payload.c,
        mu=payload.mu,
        lambda_1=payload.lambda_1,
        lambda_2=payload.lambda_2,
        lambda_3=payload.lambda_3,
    )

    escenario = guardar_escenario(
        db=db,
        payload=payload,
        lambda_total=lambda_total,
        rho=rho,
        wq1=wq1,
        wq2=wq2,
        wq3=wq3,
    )

    return SimulacionResponse(
        id=escenario.id,
        c=escenario.c,
        mu=escenario.mu,
        lambda_1=escenario.lambda_1,
        lambda_2=escenario.lambda_2,
        lambda_3=escenario.lambda_3,
        lambda_total=escenario.lambda_total,
        rho=escenario.rho,
        wq1=escenario.wq1 or 0.0,
        wq2=escenario.wq2 or 0.0,
        wq3=escenario.wq3 or 0.0,
        sistema_saturado=escenario.sistema_saturado,
        created_at=escenario.created_at,
    )