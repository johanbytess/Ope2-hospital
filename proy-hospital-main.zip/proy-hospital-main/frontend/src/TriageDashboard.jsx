import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell,
  Legend, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import './TriageDashboard.css';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const DEFAULTS = { c: 4, mu: 4.5, lambda_1: 1.2, lambda_2: 2.4, lambda_3: 4.8 };

const SLIDERS = [
  { key: 'c',        label: 'Medicos de Guardia',       min: 1,   max: 12, step: 1,   unit: 'med.',  tc: '#0891b2', ico: 'MD' },
  { key: 'mu',       label: 'Capacidad por Medico',     min: 0.5, max: 10, step: 0.5, unit: 'pac/h', tc: '#0891b2', ico: 'T' },
  { key: 'lambda_1', label: 'Llegadas Codigo Rojo',     min: 0,   max: 10, step: 0.1, unit: 'pac/h', tc: '#dc2626', ico: 'R' },
  { key: 'lambda_2', label: 'Llegadas Codigo Amarillo', min: 0,   max: 15, step: 0.1, unit: 'pac/h', tc: '#d97706', ico: 'A' },
  { key: 'lambda_3', label: 'Llegadas Codigo Verde',    min: 0,   max: 24, step: 0.1, unit: 'pac/h', tc: '#16a34a', ico: 'V' },
];

const PRESETS = [
  { label: 'Diurno Estable',  tag: 'NORMAL',  v: { c: 4, mu: 4.5, lambda_1: 1.0, lambda_2: 2.0, lambda_3: 4.0 } },
  { label: 'Pico Nocturno',   tag: 'ALTO',    v: { c: 3, mu: 3.5, lambda_1: 1.4, lambda_2: 3.4, lambda_3: 6.2 } },
  { label: 'Crisis Masiva',   tag: 'CRITICO', v: { c: 2, mu: 3.0, lambda_1: 3.0, lambda_2: 5.0, lambda_3: 8.0 } },
  { label: 'Refuerzo Max',    tag: 'OPTIMO',  v: { c: 8, mu: 5.0, lambda_1: 1.2, lambda_2: 2.8, lambda_3: 5.0 } },
];

const WQ_META = [
  { key: 'wq1', label: 'Codigo Rojo',     sub: 'Emergencia Vital',     color: '#dc2626', light: '#fef2f2', border: '#fecaca', targetMin: 10,  trend: 1 },
  { key: 'wq2', label: 'Codigo Amarillo', sub: 'Urgencia Prioritaria', color: '#d97706', light: '#fffbeb', border: '#fde68a', targetMin: 30,  trend: -1 },
  { key: 'wq3', label: 'Codigo Verde',    sub: 'Atencion Rutinaria',   color: '#16a34a', light: '#f0fdf4', border: '#bbf7d0', targetMin: 60,  trend: 0 },
];

const MOCK_PATIENTS = [
  { id: 'HC-2026-041', time: '16:02', sex: 'M', age: 72, code: 1, reason: 'PCR' },
  { id: 'HC-2026-042', time: '16:05', sex: 'F', age: 45, code: 2, reason: 'Disnea' },
  { id: 'HC-2026-043', time: '16:11', sex: 'M', age: 28, code: 3, reason: 'Luxacion' },
  { id: 'HC-2026-044', time: '16:14', sex: 'F', age: 61, code: 1, reason: 'IAM STEMI' },
  { id: 'HC-2026-045', time: '16:18', sex: 'M', age: 8,  code: 2, reason: 'Fiebre alta' },
  { id: 'HC-2026-046', time: '16:23', sex: 'F', age: 33, code: 3, reason: 'Cefalea' },
  { id: 'HC-2026-047', time: '16:29', sex: 'M', age: 55, code: 2, reason: 'Dolor abdom.' },
  { id: 'HC-2026-048', time: '16:31', sex: 'F', age: 79, code: 1, reason: 'ACV isquemico' },
  { id: 'HC-2026-049', time: '16:36', sex: 'M', age: 42, code: 3, reason: 'Contusion' },
  { id: 'HC-2026-050', time: '16:40', sex: 'F', age: 19, code: 2, reason: 'Crisis asma' },
];

const TREND_DATA = [
  { hora: '05:00', rojo: 0, amarillo: 1, verde: 2 },
  { hora: '06:00', rojo: 1, amarillo: 2, verde: 4 },
  { hora: '07:00', rojo: 1, amarillo: 3, verde: 5 },
  { hora: '08:00', rojo: 2, amarillo: 4, verde: 7 },
  { hora: '09:00', rojo: 2, amarillo: 5, verde: 9 },
  { hora: '10:00', rojo: 1, amarillo: 4, verde: 8 },
  { hora: '11:00', rojo: 3, amarillo: 6, verde: 10 },
  { hora: '12:00', rojo: 2, amarillo: 5, verde: 11 },
  { hora: '13:00', rojo: 1, amarillo: 4, verde: 9 },
  { hora: '14:00', rojo: 2, amarillo: 5, verde: 8 },
  { hora: '15:00', rojo: 3, amarillo: 7, verde: 12 },
  { hora: '16:00', rojo: 2, amarillo: 5, verde: 10 },
];

const SUPERVISORS = ['Dra. Quispe', 'Dr. Mamani', 'Dra. Choque', 'Dr. Copa', 'Dra. Flores'];

const DEFAULT_HOSPITAL_PROFILE = {
  name: 'Hospital del Norte',
  short: 'HDN',
  mark: 'HN',
  city: 'El Alto, Bolivia',
  level: 'Tercer Nivel',
  beds: 220,
  specialties: ['Medicina Interna', 'Cirugia General', 'Pediatria', 'Ginecologia', 'Traumatologia', 'Imagenologia'],
  services: ['Triage 24/7', 'Unidad de choque', 'Laboratorio clinico', 'Hospitalizacion critica'],
};

const DEFAULT_USER = {
  name: 'Lic. Mariela Quispe',
  role: 'Supervisora de Triage',
  shift: 'Turno tarde',
};

const QUICK_ACTIONS = [
  { label: 'Reset operativo', mode: 'reset' },
  { label: 'Cargar ultimo escenario', mode: 'last' },
  { label: 'Refuerzo maximo', mode: 'boost' },
];

const MODULE_TITLES = {
  'Centro de Comando': 'Centro de Comando Hospitalario',
  'Gestion de Camas': 'Gestion Integral de Camas',
  Pacientes: 'Seguimiento de Pacientes',
  Personal: 'Coordinacion del Personal',
  Analitica: 'Analitica Operativa',
  'Simulador de Triage': 'Simulador de Triage',
  Administracion: 'Administracion de Cuentas',
};

const COMMAND_KPIS = [
  { label: 'Ocupacion hospitalaria', value: '84%', sub: '185 de 220 camas activas', tone: 'kpi-blue', mark: 'O' },
  { label: 'Pacientes en observacion', value: '27', sub: '9 en critica, 18 en seguimiento', tone: 'kpi-teal', mark: 'P' },
  { label: 'Cirugias programadas', value: '14', sub: '3 de alta prioridad hoy', tone: 'kpi-green', mark: 'Q' },
  { label: 'Ambulancias en ruta', value: '5', sub: 'ETA media 12 min', tone: 'kpi-purple', mark: 'A' },
];

const BED_UNITS = [
  { unit: 'UCI Adultos', total: 20, occupied: 18, available: 2, isolation: 2, cleaning: 1, status: 'Critico' },
  { unit: 'Emergencias', total: 42, occupied: 34, available: 8, isolation: 3, cleaning: 2, status: 'Alto' },
  { unit: 'Pediatria', total: 28, occupied: 19, available: 9, isolation: 1, cleaning: 1, status: 'Estable' },
  { unit: 'Ginecologia', total: 26, occupied: 20, available: 6, isolation: 0, cleaning: 1, status: 'Estable' },
  { unit: 'Cirugia', total: 36, occupied: 31, available: 5, isolation: 1, cleaning: 3, status: 'Alto' },
];

const PATIENT_RECORDS = [
  { id: 'HDN-3012', name: 'Rosa Mamani', service: 'Medicina Interna', stage: 'Hospitalizacion', doctor: 'Dr. Copa', risk: 'Medio', eta: '2 dias', bed: 'MI-214' },
  { id: 'HDN-3013', name: 'Carlos Quisbert', service: 'Traumatologia', stage: 'Prequirurgico', doctor: 'Dra. Flores', risk: 'Alto', eta: '6 h', bed: 'TR-108' },
  { id: 'HDN-3014', name: 'Mateo Condori', service: 'Pediatria', stage: 'Observacion', doctor: 'Dr. Mamani', risk: 'Medio', eta: '18 h', bed: 'PD-009' },
  { id: 'HDN-3015', name: 'Julia Apaza', service: 'Ginecologia', stage: 'Alta clinica', doctor: 'Dra. Choque', risk: 'Bajo', eta: '4 h', bed: 'GO-016' },
  { id: 'HDN-3016', name: 'Wilmer Ticona', service: 'UCI', stage: 'Ventilacion mecanica', doctor: 'Dr. Quispe', risk: 'Critico', eta: 'Monitor continuo', bed: 'UCI-04' },
];

const STAFF_ROSTER = [
  { area: 'Emergencias', lead: 'Lic. Mariela Quispe', doctors: 8, nurses: 14, techs: 4, coverage: 'Completa', incidents: 1 },
  { area: 'UCI', lead: 'Dra. Choque', doctors: 5, nurses: 11, techs: 3, coverage: 'Ajustada', incidents: 2 },
  { area: 'Pediatria', lead: 'Dr. Mamani', doctors: 4, nurses: 9, techs: 2, coverage: 'Completa', incidents: 0 },
  { area: 'Quirófanos', lead: 'Dr. Copa', doctors: 6, nurses: 8, techs: 5, coverage: 'Ajustada', incidents: 1 },
];

const ROLE_SUMMARY = [
  { name: 'Administradora', team: 'Direccion y TI', count: 2, focus: 'Cuentas y modulos' },
  { name: 'Supervisora de Triage', team: 'Emergencias', count: 4, focus: 'Prioridades y flujo' },
  { name: 'Jefa de Enfermeria', team: 'Hospitalizacion', count: 3, focus: 'Cobertura de salas' },
  { name: 'Medico de Guardia', team: 'Guardia activa', count: 9, focus: 'Atencion asistencial' },
];

const ANALYTICS_OVERVIEW = [
  { hour: '07:00', ingresos: 18, altas: 4, camas: 74 },
  { hour: '09:00', ingresos: 24, altas: 7, camas: 78 },
  { hour: '11:00', ingresos: 29, altas: 9, camas: 81 },
  { hour: '13:00', ingresos: 34, altas: 10, camas: 84 },
  { hour: '15:00', ingresos: 31, altas: 13, camas: 82 },
  { hour: '17:00', ingresos: 27, altas: 11, camas: 80 },
];

const AMBULANCE_QUEUE = [
  { code: 'AMB-04', origin: 'Villa Adela', eta: '6 min', patient: 'Trauma toracico', priority: 'Alta' },
  { code: 'AMB-02', origin: 'Rio Seco', eta: '11 min', patient: 'EVC probable', priority: 'Alta' },
  { code: 'AMB-07', origin: 'Senkata', eta: '14 min', patient: 'Dolor abdominal', priority: 'Media' },
];

const NAV_ITEMS = [
  { label: 'Centro de Comando', active: true,  badge: null },
  { label: 'Gestion de Camas',  active: false, badge: '17' },
  { label: 'Pacientes', active: false, badge: '5' },
  { label: 'Personal',  active: false, badge: '2' },
  { label: 'Analitica', active: false, badge: null },
  { label: 'Simulador de Triage', active: false, badge: null },
  { label: 'Administracion', active: false, badge: '4' },
];

function fmtH(v) {
  const n = Number(v || 0);
  if (n < 0.0167) return (n * 60).toFixed(1) + ' min';
  return n.toFixed(3) + ' h';
}
function fmtMin(v) { return (Number(v || 0) * 60).toFixed(1) + ' min'; }
function fmtTime(ts) {
  return new Intl.DateTimeFormat('es-PE', {
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    day: '2-digit', month: '2-digit',
  }).format(new Date(ts));
}
function rhoStatus(rho) {
  if (rho >= 1)    return { label: 'SATURADO', cls: 'st-critical' };
  if (rho >= 0.9)  return { label: 'CRITICO',  cls: 'st-critical' };
  if (rho >= 0.75) return { label: 'TENSION',  cls: 'st-warning' };
  return               { label: 'ESTABLE',  cls: 'st-ok' };
}
function codeColor(code) {
  if (code === 1) return { bg: '#fef2f2', color: '#dc2626', label: 'ROJO' };
  if (code === 2) return { bg: '#fffbeb', color: '#d97706', label: 'AMARI.' };
  return { bg: '#f0fdf4', color: '#16a34a', label: 'VERDE' };
}

function initials(name) {
  return String(name || '')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0]?.toUpperCase() || '')
    .join('') || 'OP';
}

function IcoBed()   { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('path', { d:'M2 12h20M2 12V8a2 2 0 012-2h16a2 2 0 012 2v4M2 12v5a1 1 0 001 1h18a1 1 0 001-1v-5' })); }
function IcoFile()  { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('path', { d:'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z' }), React.createElement('polyline', { points:'14 2 14 8 20 8' })); }
function IcoUsers() { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('path', { d:'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2' }), React.createElement('circle', { cx:9, cy:7, r:4 }), React.createElement('path', { d:'M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75' })); }
function IcoChart() { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('line', { x1:18, y1:20, x2:18, y2:10 }), React.createElement('line', { x1:12, y1:20, x2:12, y2:4 }), React.createElement('line', { x1:6, y1:20, x2:6, y2:14 })); }
function IcoDash()  { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('rect', { x:3, y:3, width:7, height:7, rx:1 }), React.createElement('rect', { x:14, y:3, width:7, height:7, rx:1 }), React.createElement('rect', { x:3, y:14, width:7, height:7, rx:1 }), React.createElement('rect', { x:14, y:14, width:7, height:7, rx:1 })); }
function IcoBell()  { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('path', { d:'M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9' }), React.createElement('path', { d:'M13.73 21a2 2 0 01-3.46 0' })); }
function IcoPulse() { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('polyline', { points:'22 12 18 12 15 21 9 3 6 12 2 12' })); }
function IcoLock()  { return React.createElement('svg', { width:18, height:18, fill:'none', stroke:'currentColor', strokeWidth:2, viewBox:'0 0 24 24' }, React.createElement('rect', { x:3, y:11, width:18, height:10, rx:2 }), React.createElement('path', { d:'M7 11V7a5 5 0 0110 0v4' })); }
function IcoUp()    { return React.createElement('svg', { width:13, height:13, fill:'none', stroke:'currentColor', strokeWidth:2.5, viewBox:'0 0 24 24' }, React.createElement('polyline', { points:'23 6 13.5 15.5 8.5 10.5 1 18' }), React.createElement('polyline', { points:'17 6 23 6 23 12' })); }
function IcoDown()  { return React.createElement('svg', { width:13, height:13, fill:'none', stroke:'currentColor', strokeWidth:2.5, viewBox:'0 0 24 24' }, React.createElement('polyline', { points:'23 18 13.5 8.5 8.5 13.5 1 6' }), React.createElement('polyline', { points:'17 18 23 18 23 12' })); }
function IcoFlat()  { return React.createElement('svg', { width:13, height:13, fill:'none', stroke:'currentColor', strokeWidth:2.5, viewBox:'0 0 24 24' }, React.createElement('line', { x1:5, y1:12, x2:19, y2:12 })); }

const NAV_ICONS = [IcoDash, IcoBed, IcoFile, IcoUsers, IcoChart, IcoPulse, IcoLock];

function ChartTip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="chart-tip">
      <div className="chart-tip-label">{label}</div>
      {payload.map((p, i) => (
        <div key={i} className="chart-tip-row">
          <span className="chart-tip-dot" style={{ background: p.color || p.fill }}></span>
          <span className="chart-tip-name">{p.name || p.dataKey}</span>
          <span className="chart-tip-val">{typeof p.value === 'number' ? p.value.toFixed(2) + ' min' : p.value}</span>
        </div>
      ))}
    </div>
  );
}

function TrendTip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="chart-tip">
      <div className="chart-tip-label">{label}</div>
      {payload.map((p, i) => (
        <div key={i} className="chart-tip-row">
          <span className="chart-tip-dot" style={{ background: p.stroke }}></span>
          <span className="chart-tip-name">{p.name}</span>
          <span className="chart-tip-val">{p.value} pac</span>
        </div>
      ))}
    </div>
  );
}

function TriageVisualizer({ c, lambda_1, lambda_2, lambda_3, rho, saturated }) {
  const [queue, setQueue] = useState([]);
  const [busyDoctors, setBusyDoctors] = useState(0);

  useEffect(() => {
    const totalLambda = lambda_1 + lambda_2 + lambda_3;
    const targetQueueSize = saturated ? 45 : Math.floor((rho * rho) * 15);
    
    const colors = [];
    for(let i=0; i < targetQueueSize; i++) {
      const r = Math.random() * totalLambda;
      if (r < lambda_1) colors.push('rojo');
      else if (r < lambda_1 + lambda_2) colors.push('amarillo');
      else colors.push('verde');
    }
    setQueue(colors);

    const targetBusy = saturated ? c : Math.min(c, Math.floor(rho * c));
    setBusyDoctors(targetBusy);
  }, [c, lambda_1, lambda_2, lambda_3, rho, saturated]);

  return (
    <div className="triage-visualizer-card">
      <div className="visualizer-hdr">
        <div>
          <div className="visualizer-title">Flujo en Vivo del Triage (M/M/c)</div>
          <div className="visualizer-sub">Representacion grafica de llegadas, espera y atencion medica</div>
        </div>
        <div className={`chart-pill ${saturated ? 'st-critical' : rho >= 0.75 ? 'st-warning' : 'st-ok'}`}>
          {saturated ? 'SISTEMA COLAPSADO' : rho >= 0.75 ? 'TENSION OPERATIVA' : 'SISTEMA FLUIDO'}
        </div>
      </div>
      
      <div className="visualizer-stage">
        <div className="vis-section" style={{ flex: 0.5 }}>
          <div className="vis-section-title">Llegadas (λ)</div>
          <div className="vis-arrow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </div>
        </div>
        
        <div className="vis-section" style={{ flex: 1.5 }}>
          <div className="vis-section-title">Cola de Espera (Wq)</div>
          <div className={`vis-queue ${saturated ? 'saturated' : ''}`}>
            {queue.map((color, i) => (
              <div key={i} className={`vis-patient ${color}`} style={{ animationDelay: `${i * 0.04}s` }}></div>
            ))}
          </div>
        </div>

        <div className="vis-section" style={{ flex: 0.5 }}>
          <div className="vis-arrow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </div>
        </div>

        <div className="vis-section" style={{ flex: 1.5 }}>
          <div className="vis-section-title">Medicos (c)</div>
          <div className="vis-doctors">
            {Array.from({ length: c }).map((_, i) => (
              <div key={i} className={`vis-doctor ${i < busyDoctors ? 'busy' : ''}`}>
                M{i + 1}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TriageDashboard({
  hospitalProfile = DEFAULT_HOSPITAL_PROFILE,
  currentUser = DEFAULT_USER,
  accounts = [],
  roles = [],
  onCreateAccount,
  onUpdateAccountRole,
  onLogout,
}) {
  const [params, setParams]       = useState(DEFAULTS);
  const [result, setResult]       = useState(null);
  const [history, setHistory]     = useState([]);
  const [saturated, setSaturated] = useState(false);
  const [errMsg, setErrMsg]       = useState('');
  const [loading, setLoading]     = useState(false);
  const [now, setNow]             = useState(Date.now());
  const [selectedNav, setSelectedNav] = useState(NAV_ITEMS[0].label);
  const [selectedPreset, setSelectedPreset] = useState(null);
  const [selectedPatient, setSelectedPatient] = useState(MOCK_PATIENTS[0]);
  const [selectedHistoryId, setSelectedHistoryId] = useState(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showHospitalWelcome, setShowHospitalWelcome] = useState(true);
  const [patientRecords, setPatientRecords] = useState(PATIENT_RECORDS);
  const [patientForm, setPatientForm] = useState({ name: '', service: 'Medicina Interna', stage: 'Observacion', doctor: 'Dr. Mamani', risk: 'Medio', eta: '12 h', bed: 'Pendiente' });
  const [accountForm, setAccountForm] = useState({ name: '', email: '', password: '', role: roles[0]?.label || 'Administradora', shift: 'Turno tarde' });
  const [adminMessage, setAdminMessage] = useState('');
  const abortRef                  = useRef(null);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    setShowHospitalWelcome(true);
  }, [currentUser.id]);

  const loadHistory = useCallback(async () => {
    try {
      const r = await fetch(API + '/escenarios?limit=8');
      if (r.ok) setHistory(await r.json());
    } catch (_) {}
  }, []);

  const simulate = useCallback(async (p, signal) => {
    setLoading(true);
    try {
      const r = await fetch(API + '/simular', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(p),
        signal,
      });
      const data = await r.json();
      if (!r.ok) { setResult(null); setSaturated(true); setErrMsg(data.detail || 'Sistema Saturado'); }
      else        { setResult(data); setSaturated(false); setErrMsg(''); }
    } catch (e) {
      if (e.name !== 'AbortError') { setResult(null); setSaturated(false); setErrMsg('Sin conexion con el backend.'); }
    } finally {
      setLoading(false);
      loadHistory();
    }
  }, [loadHistory]);

  useEffect(() => {
    if (abortRef.current) abortRef.current.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    const t = setTimeout(() => simulate(params, ctrl.signal), 450);
    return () => { ctrl.abort(); clearTimeout(t); };
  }, [params, simulate]);

  useEffect(() => { loadHistory(); }, [loadHistory]);

  function change(key, raw) {
    setParams(p => ({ ...p, [key]: key === 'c' ? parseInt(raw, 10) : parseFloat(raw) }));
  }

  function applyPreset(preset) {
    setSelectedPreset(preset.label);
    setParams(preset.v);
  }

  function applyHistoryScenario(row) {
    setSelectedHistoryId(row.id);
    setSelectedPreset(null);
    setParams({
      c: row.c,
      mu: row.mu,
      lambda_1: row.lambda_1,
      lambda_2: row.lambda_2,
      lambda_3: row.lambda_3,
    });
  }

  function runQuickAction(mode) {
    if (mode === 'reset') {
      setSelectedHistoryId(null);
      setSelectedPreset(null);
      setParams(DEFAULTS);
      return;
    }
    if (mode === 'boost') {
      applyPreset(PRESETS[3]);
      return;
    }
    if (mode === 'last' && history[0]) {
      applyHistoryScenario(history[0]);
    }
  }

  function updatePatientForm(key, value) {
    setPatientForm(prev => ({ ...prev, [key]: value }));
  }

  function submitPatient(event) {
    event.preventDefault();
    if (!patientForm.name.trim()) return;
    const next = {
      id: `HDN-${3000 + patientRecords.length + 20}`,
      name: patientForm.name.trim(),
      service: patientForm.service,
      stage: patientForm.stage,
      doctor: patientForm.doctor,
      risk: patientForm.risk,
      eta: patientForm.eta,
      bed: patientForm.bed,
    };
    setPatientRecords(prev => [next, ...prev]);
    setPatientForm({ name: '', service: 'Medicina Interna', stage: 'Observacion', doctor: 'Dr. Mamani', risk: 'Medio', eta: '12 h', bed: 'Pendiente' });
  }

  function updateAccountForm(key, value) {
    setAccountForm(prev => ({ ...prev, [key]: value }));
  }

  function submitAccount(event) {
    event.preventDefault();
    if (!isAdmin || !onCreateAccount) return;
    if (!accountForm.name.trim() || !accountForm.email.trim() || !accountForm.password.trim()) {
      setAdminMessage('Completa nombre, correo y contrasena para crear la cuenta.');
      return;
    }
    const normalizedEmail = accountForm.email.trim().toLowerCase();
    if (accounts.some(account => account.email.toLowerCase() === normalizedEmail)) {
      setAdminMessage('Ya existe una cuenta con ese correo institucional.');
      return;
    }
    onCreateAccount({
      name: accountForm.name.trim(),
      email: normalizedEmail,
      password: accountForm.password,
      role: accountForm.role,
      shift: accountForm.shift,
      status: 'Activa',
    });
    setAdminMessage('Cuenta creada y disponible para el siguiente inicio de sesion.');
    setAccountForm({ name: '', email: '', password: '', role: roles[0]?.label || 'Administradora', shift: 'Turno tarde' });
  }

  const lambda_total = params.lambda_1 + params.lambda_2 + params.lambda_3;
  const capacity     = params.c * params.mu;
  const rho_preview  = capacity > 0 ? lambda_total / capacity : 0;
  const effectiveRho = saturated ? 1 : (result ? result.rho : rho_preview);
  const st           = rhoStatus(effectiveRho);
  const weightedWq = (!saturated && result && lambda_total > 0)
    ? (result.wq1 * params.lambda_1 + result.wq2 * params.lambda_2 + result.wq3 * params.lambda_3) / lambda_total
    : null;
  const targetCompliance = !saturated && result
    ? WQ_META.filter(m => (result[m.key] * 60) <= m.targetMin).length
    : 0;
  const currentLoad = capacity > 0 ? Math.min((lambda_total / capacity) * 100, 100) : 0;
  const userInitials = initials(currentUser.name);
  const isAdmin = currentUser.role === 'Administradora';
  const visibleNavItems = isAdmin ? NAV_ITEMS : NAV_ITEMS.filter(item => item.label !== 'Administracion');
  const isTriageModule = selectedNav === 'Simulador de Triage';
  const activeTitle = MODULE_TITLES[selectedNav] || selectedNav;
  const notifications = [
    { id: 'n1', type: st.label, title: 'Estado operacional', text: `El sistema se encuentra en nivel ${st.label.toLowerCase()} con rho ${effectiveRho.toFixed(3)}.` },
    { id: 'n2', type: selectedPatient.code === 1 ? 'Critico' : 'Seguimiento', title: `Paciente ${selectedPatient.id}`, text: `${selectedPatient.reason} · Codigo ${codeColor(selectedPatient.code).label} · ${selectedPatient.sex}/${selectedPatient.age}` },
    { id: 'n3', type: 'Capacidad', title: 'Especialidades activas', text: `${hospitalProfile.specialties.length} servicios priorizados para guardia actual.` },
  ];

  const barData = WQ_META.map(m => ({
    name: m.label.replace('Codigo ', ''),
    Actual:  saturated ? 0 : (result ? Number((result[m.key] * 60).toFixed(2)) : 0),
    Objetivo: m.targetMin,
    color: m.color,
  }));

  useEffect(() => {
    if (!isAdmin && selectedNav === 'Administracion') {
      setSelectedNav('Centro de Comando');
    }
  }, [isAdmin, selectedNav]);

  const systemSidebar = (
    <aside className="ops-planner ops-planner-system">
      <div className="planner-title-row">
        <div className="planner-badge">HOSPITAL</div>
        <div className="planner-title">Resumen del modulo</div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Indicadores institucionales</div>
        <div className="system-stat-stack">
          <div className="system-stat-card"><span>Ocupacion actual</span><strong>84%</strong><small>185 camas ocupadas</small></div>
          <div className="system-stat-card"><span>Pacientes en transito</span><strong>31</strong><small>Urgencias, imagen y observacion</small></div>
          <div className="system-stat-card"><span>Personal de turno</span><strong>74</strong><small>Medicos, enfermeria y apoyo</small></div>
        </div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Ambulancias en ruta</div>
        <div className="system-list">
          {AMBULANCE_QUEUE.map(item => (
            <div key={item.code} className="system-list-card">
              <div className="system-list-top"><strong>{item.code}</strong><span>{item.eta}</span></div>
              <div className="system-list-main">{item.patient}</div>
              <div className="system-list-sub">{item.origin} · Prioridad {item.priority}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Servicios priorizados</div>
        <div className="system-chip-grid">
          {hospitalProfile.services.map(item => <span key={item} className="system-chip">{item}</span>)}
        </div>
      </div>
    </aside>
  );

  const triageSidebar = (
    <aside className="ops-planner">
      <div className="planner-title-row">
        <div className="planner-badge">WHAT-IF</div>
        <div className="planner-title">Operations Planner</div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Escenarios Rapidos</div>
        <div className="preset-list">
          {PRESETS.map(p => (
            <button
              key={p.label}
              type="button"
              className={'preset-btn' + (selectedPreset === p.label ? ' preset-active' : '')}
              onClick={() => applyPreset(p)}
            >
              <span className="preset-name">{p.label}</span>
              <span className={'preset-tag tag-' + p.tag.toLowerCase()}>{p.tag}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Parametros del Sistema</div>
        <div className="slider-stack">
          {SLIDERS.map(s => (
            <div key={s.key} className="slider-item">
              <div className="slider-hdr">
                <div className="slider-ico" style={{ background: s.tc + '18', color: s.tc }}>{s.ico}</div>
                <span className="slider-name">{s.label}</span>
                <span className="slider-val" style={{ color: s.tc }}>
                  {params[s.key]}<span className="slider-unit"> {s.unit}</span>
                </span>
              </div>
              <input
                type="range" min={s.min} max={s.max} step={s.step} value={params[s.key]}
                style={{ '--tc': s.tc }}
                onChange={e => change(s.key, e.target.value)}
              />
              <div className="slider-range-lbl"><span>{s.min}</span><span>{s.max}</span></div>
            </div>
          ))}
        </div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Utilizacion del Sistema</div>
        <div className="rho-box">
          <div className="rho-formula">
            rho = {lambda_total.toFixed(2)} / ({params.c} x {params.mu}) = <strong style={{ color: st.cls === 'st-ok' ? '#16a34a' : st.cls === 'st-warning' ? '#d97706' : '#dc2626' }}>{rho_preview.toFixed(3)}</strong>
          </div>
          <div className="rho-track">
            <div className={'rho-fill st-fill-' + st.cls.replace('st-','')} style={{ width: Math.min(effectiveRho * 100, 100) + '%' }}></div>
          </div>
          <div className="rho-ticks"><span>0%</span><span>75%</span><span>90%</span><span>100%</span></div>
          <div className={'rho-chip ' + st.cls}>{st.label}</div>
        </div>
      </div>

      <div className="planner-section">
        <div className="planner-section-label">Acciones Rapidas</div>
        <div className="quick-actions">
          {QUICK_ACTIONS.map(action => (
            <button
              key={action.mode}
              type="button"
              className="quick-action-btn"
              onClick={() => runQuickAction(action.mode)}
            >
              {action.label}
            </button>
          ))}
        </div>
      </div>

      <button type="button" className={'sim-btn' + (loading ? ' loading' : '')} disabled={loading} onClick={() => simulate(params, undefined)}>
        {loading ? 'Calculando...' : 'Recalcular Escenario'}
      </button>
    </aside>
  );

  const commandCenterView = (
    <>
      <div className="overview-grid">
        <section className="overview-card overview-hero">
          <div className="overview-kicker">Panel institucional</div>
          <h2 className="overview-title">{hospitalProfile.name}</h2>
          <p className="overview-text">
            Sistema integral de gestion hospitalaria con monitoreo de camas, pacientes, personal,
            ambulancias y rendimiento operativo para la guardia del {currentUser.shift.toLowerCase()}.
          </p>
          <div className="overview-meta-row">
            <span>{hospitalProfile.short}</span>
            <span>{hospitalProfile.level}</span>
            <span>{hospitalProfile.city}</span>
            <span>{currentUser.shift}</span>
          </div>
        </section>

        <section className="overview-card overview-side">
          <div className="overview-side-title">Snapshot operativo</div>
          <div className="overview-metric-row">
            <div className="overview-metric"><span>Carga actual</span><strong>{currentLoad.toFixed(0)}%</strong></div>
            <div className="overview-metric"><span>Pacientes activos</span><strong>132</strong></div>
            <div className="overview-metric"><span>Ultimo escenario</span><strong>{history[0] ? `#${history[0].id}` : 'N/A'}</strong></div>
          </div>
          <div className="overview-chip-row">
            {hospitalProfile.specialties.slice(0, 4).map(item => <span key={item} className="overview-chip">{item}</span>)}
          </div>
        </section>
      </div>

      <div className="kpi-row">
        {COMMAND_KPIS.map(item => (
          <div key={item.label} className={'kpi-card ' + item.tone}>
            <div className="kpi-inner">
              <div className="kpi-label">{item.label}</div>
              <div className="kpi-val">{item.value}</div>
              <div className="kpi-sub">{item.sub}</div>
            </div>
            <span className="kpi-bg">{item.mark}</span>
          </div>
        ))}
      </div>

      <div className="system-grid">
        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Resumen de unidades</div>
              <div className="system-panel-sub">Estado consolidado de areas asistenciales</div>
            </div>
          </div>
          <div className="system-unit-list">
            {BED_UNITS.map(unit => (
              <div key={unit.unit} className="system-unit-card">
                <div className="system-unit-top"><strong>{unit.unit}</strong><span>{unit.status}</span></div>
                <div className="system-unit-bar"><span style={{ width: `${(unit.occupied / unit.total) * 100}%` }}></span></div>
                <div className="system-unit-metrics">
                  <div><small>Ocupadas</small><strong>{unit.occupied}</strong></div>
                  <div><small>Disponibles</small><strong>{unit.available}</strong></div>
                  <div><small>Aislamiento</small><strong>{unit.isolation}</strong></div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Pacientes priorizados</div>
              <div className="system-panel-sub">Seguimiento rapido de casos activos</div>
            </div>
          </div>
          <div className="system-mini-table-wrap">
            <table className="system-mini-table">
              <thead><tr><th>Paciente</th><th>Servicio</th><th>Estado</th><th>Riesgo</th></tr></thead>
              <tbody>
                {PATIENT_RECORDS.slice(0, 4).map(row => (
                  <tr key={row.id}><td>{row.name}</td><td>{row.service}</td><td>{row.stage}</td><td>{row.risk}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </>
  );

  const bedsView = (
    <div className="module-stack">
      <div className="module-banner">
        <div>
          <div className="module-banner-kicker">Capacidad hospitalaria</div>
          <h2 className="module-banner-title">Tablero de camas y disponibilidad</h2>
        </div>
        <div className="module-banner-chip">17 solicitudes de transferencia</div>
      </div>
      <div className="system-grid system-grid-wide">
        {BED_UNITS.map(unit => (
          <section key={unit.unit} className="system-panel">
            <div className="system-panel-head">
              <div>
                <div className="system-panel-title">{unit.unit}</div>
                <div className="system-panel-sub">Control de ocupacion y limpieza</div>
              </div>
              <div className="module-banner-chip">{unit.status}</div>
            </div>
            <div className="bed-stat-row">
              <div className="bed-stat"><span>Total</span><strong>{unit.total}</strong></div>
              <div className="bed-stat"><span>Ocupadas</span><strong>{unit.occupied}</strong></div>
              <div className="bed-stat"><span>Disponibles</span><strong>{unit.available}</strong></div>
              <div className="bed-stat"><span>Limpieza</span><strong>{unit.cleaning}</strong></div>
            </div>
            <div className="system-unit-bar system-unit-bar-large"><span style={{ width: `${(unit.occupied / unit.total) * 100}%` }}></span></div>
          </section>
        ))}
      </div>
    </div>
  );

  const patientsView = (
    <div className="module-stack">
      <div className="module-banner">
        <div>
          <div className="module-banner-kicker">Historias activas</div>
          <h2 className="module-banner-title">Pacientes hospitalizados y en observacion</h2>
        </div>
        <div className="module-banner-chip">{patientRecords.length} registros</div>
      </div>
      <div className="system-grid">
        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Ingreso de nuevo paciente</div>
              <div className="system-panel-sub">Alta administrativa con datos de prueba</div>
            </div>
          </div>
          <form className="module-form" onSubmit={submitPatient}>
            <label className="module-field"><span>Nombre</span><input value={patientForm.name} onChange={e => updatePatientForm('name', e.target.value)} placeholder="Ej. Ana Condori" /></label>
            <label className="module-field"><span>Servicio</span><select value={patientForm.service} onChange={e => updatePatientForm('service', e.target.value)}><option>Medicina Interna</option><option>Pediatria</option><option>Traumatologia</option><option>Ginecologia</option><option>UCI</option></select></label>
            <label className="module-field"><span>Estado</span><select value={patientForm.stage} onChange={e => updatePatientForm('stage', e.target.value)}><option>Observacion</option><option>Hospitalizacion</option><option>Prequirurgico</option><option>Alta clinica</option></select></label>
            <label className="module-field"><span>Medico</span><input value={patientForm.doctor} onChange={e => updatePatientForm('doctor', e.target.value)} /></label>
            <label className="module-field"><span>Riesgo</span><select value={patientForm.risk} onChange={e => updatePatientForm('risk', e.target.value)}><option>Bajo</option><option>Medio</option><option>Alto</option><option>Critico</option></select></label>
            <label className="module-field"><span>Cama / ubicacion</span><input value={patientForm.bed} onChange={e => updatePatientForm('bed', e.target.value)} placeholder="Ej. MI-220" /></label>
            <label className="module-field module-field-full"><span>Tiempo estimado</span><input value={patientForm.eta} onChange={e => updatePatientForm('eta', e.target.value)} placeholder="Ej. 8 h" /></label>
            <button type="submit" className="module-submit">Registrar paciente</button>
          </form>
        </section>

        <section className="system-panel">
        <div className="table-wrap">
          <table className="hist-table">
            <thead>
              <tr><th>ID</th><th>Paciente</th><th>Servicio</th><th>Estado</th><th>Medico</th><th>Riesgo</th><th>Cama</th><th>ETA</th></tr>
            </thead>
            <tbody>
              {patientRecords.map(row => (
                <tr key={row.id} className="hist-row">
                  <td className="td-id">{row.id}</td><td>{row.name}</td><td>{row.service}</td><td>{row.stage}</td><td>{row.doctor}</td><td>{row.risk}</td><td>{row.bed}</td><td>{row.eta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        </section>
      </div>
    </div>
  );

  const staffView = (
    <div className="module-stack">
      <div className="module-banner">
        <div>
          <div className="module-banner-kicker">Cobertura de turno</div>
          <h2 className="module-banner-title">Roles, dotacion y cobertura por area</h2>
        </div>
        <div className="module-banner-chip">2 areas ajustadas</div>
      </div>
      <div className="system-grid">
        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Catalogo de roles</div>
              <div className="system-panel-sub">Permisos y alcance dentro del hospital</div>
            </div>
          </div>
          <div className="role-grid">
            {roles.map(role => (
              <div key={role.key} className="role-card">
                <div className="role-card-top"><strong>{role.label}</strong><span>{role.permissions} permisos</span></div>
                <div className="role-card-sub">{role.scope}</div>
                <p className="role-card-text">{role.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Resumen de asignacion</div>
              <div className="system-panel-sub">Distribucion por cargo y turno</div>
            </div>
          </div>
          <div className="role-grid">
            {ROLE_SUMMARY.map(role => (
              <div key={role.name} className="role-card role-card-soft">
                <div className="role-card-top"><strong>{role.name}</strong><span>{role.count} activos</span></div>
                <div className="role-card-sub">{role.team}</div>
                <p className="role-card-text">{role.focus}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
      <div className="system-grid system-grid-wide">
        {STAFF_ROSTER.map(area => (
          <section key={area.area} className="system-panel">
            <div className="system-panel-head">
              <div>
                <div className="system-panel-title">{area.area}</div>
                <div className="system-panel-sub">Responsable: {area.lead}</div>
              </div>
              <div className="module-banner-chip">{area.coverage}</div>
            </div>
            <div className="bed-stat-row">
              <div className="bed-stat"><span>Medicos</span><strong>{area.doctors}</strong></div>
              <div className="bed-stat"><span>Enfermeria</span><strong>{area.nurses}</strong></div>
              <div className="bed-stat"><span>Tecnicos</span><strong>{area.techs}</strong></div>
              <div className="bed-stat"><span>Incidencias</span><strong>{area.incidents}</strong></div>
            </div>
          </section>
        ))}
      </div>
    </div>
  );

  const adminView = (
    <div className="module-stack">
      <div className="module-banner">
        <div>
          <div className="module-banner-kicker">Control institucional</div>
          <h2 className="module-banner-title">Cuentas, credenciales y roles</h2>
        </div>
        <div className="module-banner-chip">{accounts.length} cuentas registradas</div>
      </div>
      <div className="system-grid">
        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Crear nueva cuenta</div>
              <div className="system-panel-sub">Administracion de accesos del hospital, disponible solo para la administradora</div>
            </div>
          </div>
          {adminMessage && <div className="module-message">{adminMessage}</div>}
          <form className="module-form" onSubmit={submitAccount}>
            <label className="module-field"><span>Nombre completo</span><input value={accountForm.name} onChange={e => updateAccountForm('name', e.target.value)} /></label>
            <label className="module-field"><span>Correo</span><input value={accountForm.email} onChange={e => updateAccountForm('email', e.target.value)} placeholder="usuario@hdn.bo" /></label>
            <label className="module-field"><span>Contrasena</span><input type="password" value={accountForm.password} onChange={e => updateAccountForm('password', e.target.value)} /></label>
            <label className="module-field"><span>Rol</span><select value={accountForm.role} onChange={e => updateAccountForm('role', e.target.value)}>{roles.map(role => <option key={role.key}>{role.label}</option>)}</select></label>
            <label className="module-field"><span>Turno</span><select value={accountForm.shift} onChange={e => updateAccountForm('shift', e.target.value)}><option>Turno manana</option><option>Turno tarde</option><option>Turno noche</option></select></label>
            <button type="submit" className="module-submit" disabled={!isAdmin}>Crear cuenta</button>
          </form>
        </section>

        <section className="system-panel">
          <div className="system-panel-head">
            <div>
              <div className="system-panel-title">Usuarios activos del sistema</div>
              <div className="system-panel-sub">Cambios de rol en tiempo real para la sesion actual</div>
            </div>
          </div>
          <div className="table-wrap">
            <table className="hist-table">
              <thead>
                <tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Turno</th><th>Estado</th></tr>
              </thead>
              <tbody>
                {accounts.map(account => (
                  <tr key={account.id} className="hist-row">
                    <td>{account.name}</td>
                    <td>{account.email}</td>
                    <td>
                      <select className="inline-select" value={account.role} disabled={!isAdmin} onChange={e => isAdmin && onUpdateAccountRole && onUpdateAccountRole(account.id, e.target.value)}>
                        {roles.map(role => <option key={role.key}>{role.label}</option>)}
                      </select>
                    </td>
                    <td>{account.shift}</td>
                    <td><span className="module-banner-chip">{account.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );

  const analyticsView = (
    <div className="module-stack">
      <div className="module-banner">
        <div>
          <div className="module-banner-kicker">Datos operativos</div>
          <h2 className="module-banner-title">Ingresos, altas y ocupacion durante la jornada</h2>
        </div>
        <div className="module-banner-chip">6 cortes horarios</div>
      </div>
      <div className="charts-row">
        <div className="chart-card">
          <div className="chart-hdr">
            <div>
              <div className="chart-title">Flujo asistencial</div>
              <div className="chart-sub">Ingresos vs altas por bloque horario</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={ANALYTICS_OVERVIEW}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} width={30} />
              <Tooltip content={<ChartTip />} />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Bar dataKey="ingresos" name="Ingresos" fill="#0891b2" radius={[6, 6, 0, 0]} />
              <Bar dataKey="altas" name="Altas" fill="#16a34a" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <div className="chart-hdr">
            <div>
              <div className="chart-title">Tendencia de ocupacion</div>
              <div className="chart-sub">Porcentaje de ocupacion en la jornada</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={ANALYTICS_OVERVIEW}>
              <defs>
                <linearGradient id="gBeds" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563eb" stopOpacity={0.28}/><stop offset="95%" stopColor="#2563eb" stopOpacity={0}/></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} width={30} />
              <Tooltip content={<TrendTip />} />
              <Area type="monotone" dataKey="camas" name="Ocupacion" stroke="#2563eb" strokeWidth={2} fill="url(#gBeds)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );

  const triageView = (
    <>
      <div className="overview-grid">
        <section className="overview-card overview-hero">
          <div className="overview-kicker">Modulo clinico especializado</div>
          <h2 className="overview-title">Simulador de Triage</h2>
          <p className="overview-text">
            Esta funcionalidad modela la cola de atencion en emergencias y permite ensayar escenarios
            para redistribuir recursos antes de que el sistema entre en saturacion.
          </p>
          <div className="overview-meta-row">
            <span>{hospitalProfile.short}</span>
            <span>Modelo M/M/c</span>
            <span>Prioridades no expropiativas</span>
          </div>
        </section>

        <section className="overview-card overview-side">
          <div className="overview-side-title">Snapshot del simulador</div>
          <div className="overview-metric-row">
            <div className="overview-metric"><span>Carga actual</span><strong>{currentLoad.toFixed(0)}%</strong></div>
            <div className="overview-metric"><span>Targets cumplidos</span><strong>{targetCompliance}/3</strong></div>
            <div className="overview-metric"><span>Espera ponderada</span><strong>{weightedWq !== null ? fmtMin(weightedWq) : 'N/A'}</strong></div>
          </div>
        </section>
      </div>

      <div className="kpi-row">
        <div className="kpi-card kpi-blue">
          <div className="kpi-inner">
            <div className="kpi-label">Medicos Activos</div>
            <div className="kpi-val">{params.c}</div>
            <div className="kpi-sub">Cap. {capacity.toFixed(1)} pac/h</div>
          </div>
          <span className="kpi-bg">M</span>
        </div>
        <div className="kpi-card kpi-teal">
          <div className="kpi-inner">
            <div className="kpi-label">Demanda Total</div>
            <div className="kpi-val">{lambda_total.toFixed(1)}<span> pac/h</span></div>
            <div className="kpi-sub">R:{params.lambda_1} A:{params.lambda_2} V:{params.lambda_3}</div>
          </div>
          <span className="kpi-bg">D</span>
        </div>
        <div className={'kpi-card ' + (effectiveRho >= 0.9 ? 'kpi-red' : effectiveRho >= 0.75 ? 'kpi-amber' : 'kpi-green')}>
          <div className="kpi-inner">
            <div className="kpi-label">Utilizacion rho</div>
            <div className="kpi-val">{effectiveRho.toFixed(3)}</div>
            <div className="kpi-sub">{effectiveRho >= 0.75 ? 'Revisar dotacion' : 'Sistema normal'}</div>
          </div>
          <span className="kpi-bg">p</span>
        </div>
        <div className="kpi-card kpi-purple">
          <div className="kpi-inner">
            <div className="kpi-label">Espera Ponderada</div>
            <div className="kpi-val">{weightedWq !== null ? fmtMin(weightedWq) : '—'}</div>
            <div className="kpi-sub">Media ponderada por flujo</div>
          </div>
          <span className="kpi-bg">W</span>
        </div>
      </div>

      {saturated && (
        <div className="alert-sat">
          <div className="alert-sat-icon">🚨</div>
          <div className="alert-sat-body">
            <div className="alert-sat-title">SISTEMA SATURADO — RIESGO DE COLAPSO OPERATIVO</div>
            <div className="alert-sat-text">
              Demanda ({lambda_total.toFixed(1)} pac/h) supera Capacidad ({capacity.toFixed(1)} pac/h).
              Factor rho mayor o igual a 1 implica cola infinita. Incrementa medicos o activa protocolo de contingencia.
            </div>
          </div>
          <div className="alert-sat-actions">
            <button type="button" className="alert-btn" onClick={() => applyPreset(PRESETS[3])}>Activar Plan B</button>
            <button type="button" className="alert-btn secondary" onClick={() => setShowNotifications(true)}>Notificar Direccion</button>
          </div>
        </div>
      )}
      {!saturated && errMsg && (
        <div className="alert-conn"><span>!</span> {errMsg}</div>
      )}

      <TriageVisualizer 
        c={params.c} 
        lambda_1={params.lambda_1} 
        lambda_2={params.lambda_2} 
        lambda_3={params.lambda_3} 
        rho={effectiveRho} 
        saturated={saturated} 
      />

      <div className="mid-row">
        <div className="wq-col">
          {WQ_META.map(m => {
            const wqVal = !saturated && result ? result[m.key] : null;
            const wqMin = wqVal !== null ? wqVal * 60 : null;
            const over  = wqMin !== null && wqMin > m.targetMin;
            return (
              <div key={m.key} className="wq-card" style={{ '--wc': m.color, '--wb': m.light, '--wbord': m.border }}>
                <div className="wq-top">
                  <div>
                    <div className="wq-badge" style={{ background: m.color }}>{m.label}</div>
                    <div className="wq-sub">{m.sub}</div>
                  </div>
                  <div className={'wq-trend ' + (m.trend > 0 ? 'trend-up' : m.trend < 0 ? 'trend-dn' : 'trend-fl')}>
                    {m.trend > 0 ? <IcoUp /> : m.trend < 0 ? <IcoDown /> : <IcoFlat />}
                  </div>
                </div>
                <div className="wq-val" style={{ color: over ? '#dc2626' : m.color }}>
                  {wqVal !== null ? fmtH(wqVal) : '—'}
                </div>
                <div className="wq-target-row">
                  <span className="wq-target-lbl">Target clinico:</span>
                  <span className={'wq-target-val ' + (over ? 'target-miss' : 'target-ok')}>
                    {over ? 'EXCEDIDO' : 'OK'} &lt;{m.targetMin}min
                    {wqMin !== null ? ' · ' + wqMin.toFixed(1) + 'min actual' : ''}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="patient-feed">
          <div className="feed-hdr">
            <div className="feed-title">Live Patient Feed</div>
            <div className="feed-sub">Ultimos 10 pacientes triageados</div>
            <div className="feed-live"><span className="live-dot"></span>EN VIVO · MOCK</div>
          </div>
          <div className="feed-wrap">
            <table className="feed-table">
              <thead>
                <tr>
                  <th>Hora</th><th>ID Paciente</th><th>S/E</th><th>Motivo</th><th>Codigo</th>
                </tr>
              </thead>
              <tbody>
                {MOCK_PATIENTS.map(p => {
                  const c = codeColor(p.code);
                  return (
                    <tr key={p.id} className={'feed-row' + (selectedPatient.id === p.id ? ' feed-row-active' : '')} onClick={() => setSelectedPatient(p)}>
                      <td className="td-mono">{p.time}</td>
                      <td className="td-id">{p.id}</td>
                      <td className="td-se">{p.sex}/{p.age}</td>
                      <td>{p.reason}</td>
                      <td><span className="td-code" style={{ background: c.bg, color: c.color }}>{c.label}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="patient-spotlight">
            <div className="patient-spotlight-head">
              <div>
                <div className="patient-spotlight-title">Paciente seleccionado</div>
                <div className="patient-spotlight-sub">Seguimiento rapido para decision de guardia</div>
              </div>
              <span className="patient-spotlight-tag" style={{ background: codeColor(selectedPatient.code).bg, color: codeColor(selectedPatient.code).color }}>
                {codeColor(selectedPatient.code).label}
              </span>
            </div>
            <div className="patient-spotlight-grid">
              <div><span>ID</span><strong>{selectedPatient.id}</strong></div>
              <div><span>Ingreso</span><strong>{selectedPatient.time}</strong></div>
              <div><span>Sexo/Edad</span><strong>{selectedPatient.sex}/{selectedPatient.age}</strong></div>
              <div><span>Motivo</span><strong>{selectedPatient.reason}</strong></div>
            </div>
          </div>
        </div>
      </div>

      <div className="charts-row">
        <div className="chart-card">
          <div className="chart-hdr">
            <div>
              <div className="chart-title">Operational vs. Target Waiting Times</div>
              <div className="chart-sub">Simulacion actual — Modelo M/M/c con Prioridades sin Interrupcion</div>
            </div>
            <div className={'chart-pill ' + st.cls}>{st.label}</div>
          </div>
          {saturated ? (
            <div className="chart-empty">Sistema saturado — sin datos de espera</div>
          ) : (
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={barData} margin={{ top: 8, right: 16, left: 0, bottom: 4 }} barCategoryGap="32%">
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569', fontWeight: 600 }} axisLine={false} tickLine={false} />
                <YAxis tickFormatter={v => v + 'm'} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={44} />
                <Tooltip content={<ChartTip />} />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '6px' }} />
                <Bar dataKey="Actual" name="Actual (min)" radius={[6,6,0,0]} maxBarSize={48}>
                  {barData.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Bar>
                <Bar dataKey="Objetivo" name="Objetivo (min)" fill="#cbd5e1" radius={[6,6,0,0]} maxBarSize={48} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="chart-card">
          <div className="chart-hdr">
            <div>
              <div className="chart-title">Tendencia de Llegadas — Ultimas 12 h</div>
              <div className="chart-sub">Historico del dia · Mock Data · Anticipacion de picos</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={230}>
            <AreaChart data={TREND_DATA} margin={{ top: 8, right: 16, left: 0, bottom: 4 }}>
              <defs>
                <linearGradient id="gR" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#dc2626" stopOpacity={0.25}/><stop offset="95%" stopColor="#dc2626" stopOpacity={0}/></linearGradient>
                <linearGradient id="gA" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#d97706" stopOpacity={0.25}/><stop offset="95%" stopColor="#d97706" stopOpacity={0}/></linearGradient>
                <linearGradient id="gV" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#16a34a" stopOpacity={0.25}/><stop offset="95%" stopColor="#16a34a" stopOpacity={0}/></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="hora" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={24} />
              <Tooltip content={<TrendTip />} />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '6px' }} />
              <Area type="monotone" dataKey="rojo" name="Rojo" stroke="#dc2626" strokeWidth={2} fill="url(#gR)" />
              <Area type="monotone" dataKey="amarillo" name="Amarillo" stroke="#d97706" strokeWidth={2} fill="url(#gA)" />
              <Area type="monotone" dataKey="verde" name="Verde" stroke="#16a34a" strokeWidth={2} fill="url(#gV)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="history-card">
        <div className="history-hdr">
          <div>
            <div className="history-title">Registro de Simulaciones</div>
            <div className="history-sub">Persistido en SQLite — Ultimos 8 escenarios guardados</div>
          </div>
          <div className="history-count">{history.length} registros</div>
        </div>
        {history.length === 0 ? (
          <div className="history-empty">No hay simulaciones. Ajusta los parametros para comenzar.</div>
        ) : (
          <div className="table-wrap">
            <table className="hist-table">
              <thead>
                <tr>
                  <th>Hora</th><th>Estado</th><th>c</th><th>mu</th>
                  <th>Lambda total</th><th>rho</th><th>Wq Rojo</th><th>Wq Amarillo</th><th>Wq Verde</th>
                  <th>Supervisor</th><th>Costo h</th><th>Target Clin.</th>
                </tr>
              </thead>
              <tbody>
                {history.map((row, idx) => {
                  const rs   = rhoStatus(row.rho);
                  const sup  = SUPERVISORS[idx % SUPERVISORS.length];
                  const cost = (row.c * 45 * (1 + row.rho * 0.3)).toFixed(0);
                  const w1m  = row.wq1 ? row.wq1 * 60 : null;
                  const ok   = !row.sistema_saturado && w1m !== null && w1m < 10;
                  return (
                    <tr key={row.id} className={'hist-row' + (selectedHistoryId === row.id ? ' hist-row-active' : '')} onClick={() => applyHistoryScenario(row)}>
                      <td className="td-mono">{fmtTime(row.created_at)}</td>
                      <td><span className={'hist-badge ' + rs.cls}>{row.sistema_saturado ? 'SATURADO' : rs.label}</span></td>
                      <td>{row.c}</td>
                      <td>{Number(row.mu).toFixed(1)}</td>
                      <td>{Number(row.lambda_total).toFixed(1)}</td>
                      <td className={'td-rho ' + rs.cls}>{Number(row.rho).toFixed(3)}</td>
                      <td>{row.sistema_saturado ? '---' : fmtH(row.wq1)}</td>
                      <td>{row.sistema_saturado ? '---' : fmtH(row.wq2)}</td>
                      <td>{row.sistema_saturado ? '---' : fmtH(row.wq3)}</td>
                      <td className="td-sup">{sup}</td>
                      <td className="td-cost">S. {cost}</td>
                      <td>{row.sistema_saturado ? <span className="crit-no">No</span> : ok ? <span className="crit-yes">Si</span> : <span className="crit-no">No</span>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );

  const activeMainView = selectedNav === 'Centro de Comando'
    ? commandCenterView
    : selectedNav === 'Gestion de Camas'
      ? bedsView
      : selectedNav === 'Pacientes'
        ? patientsView
        : selectedNav === 'Personal'
          ? staffView
          : selectedNav === 'Analitica'
            ? analyticsView
            : selectedNav === 'Administracion'
              ? adminView
              : triageView;

  return (
    <div className="ccc-root">

      {/* ===== LEFT NAV ===== */}
      <nav className="ccc-nav">
        <div className="nav-logo">
          <div className="nav-logo-mark">{hospitalProfile.mark}</div>
          <div className="nav-logo-text">
            <span className="nav-logo-name">{hospitalProfile.name}</span>
            <span className="nav-logo-sub">El Alto · {hospitalProfile.level}</span>
          </div>
        </div>
        <div className="nav-section-lbl">MODULOS</div>
        {visibleNavItems.map(item => {
          const i = NAV_ITEMS.findIndex(navItem => navItem.label === item.label);
          const Icon = NAV_ICONS[i];
          return (
            <button
              key={item.label}
              type="button"
              className={'nav-item' + (selectedNav === item.label ? ' nav-active' : '')}
              onClick={() => setSelectedNav(item.label)}
            >
              <span className="nav-icon"><Icon /></span>
              <span className="nav-label">{item.label}</span>
              {item.badge && <span className="nav-badge">{item.badge}</span>}
            </button>
          );
        })}
        <div className="nav-spacer"></div>
        <div className="nav-divider"></div>
        <div className="nav-user">
          <div className="nav-avatar">{userInitials}</div>
          <div className="nav-user-info">
            <div className="nav-user-name">{currentUser.name}</div>
            <div className="nav-user-role">{currentUser.role}</div>
          </div>
          <div className="nav-online-dot"></div>
        </div>
      </nav>

      {/* ===== MAIN SHELL ===== */}
      <div className="ccc-shell">

        {/* HEADER */}
        <header className="ccc-header">
          <div className="header-left">
            <div className="header-breadcrumb">
              <span>TECC</span><span className="bc-sep">/</span>
              <span>{selectedNav}</span><span className="bc-sep">/</span>
              <span className="bc-active">{activeTitle}</span>
            </div>
            <h1 className="header-title">{activeTitle}</h1>
          </div>
          <div className="header-right">
            <div className="header-clock">
              <span className="clock-dot"></span>{fmtTime(now)}
            </div>
            <div className={'header-status ' + st.cls}>{st.label}</div>
            <button type="button" className="header-bell-btn" onClick={() => setShowNotifications(v => !v)}>
              <IcoBell /><span className="bell-dot">3</span>
            </button>
            <button type="button" className="header-logout-btn" onClick={() => onLogout && onLogout()}>Salir</button>
            <div className="header-avatar">{userInitials}</div>
          </div>
        </header>

        {showHospitalWelcome && (
          <div className="session-welcome-overlay">
            <section className="session-welcome-card">
              <button type="button" className="session-welcome-close" onClick={() => setShowHospitalWelcome(false)}>×</button>
              <div className="session-welcome-kicker">Bienvenida al sistema hospitalario</div>
              <h2 className="session-welcome-title">{hospitalProfile.name}</h2>
              <p className="session-welcome-text">
                Bienvenida, {currentUser.name}. Tu sesion como {currentUser.role} en {currentUser.shift.toLowerCase()} ya esta activa.
                El hospital cuenta con {hospitalProfile.beds} camas, cobertura {hospitalProfile.level} y servicios criticos habilitados para guardia continua.
              </p>
              <div className="session-welcome-stats">
                <div><span>Especialidades</span><strong>{hospitalProfile.specialties.length}</strong></div>
                <div><span>Servicios</span><strong>{hospitalProfile.services.length}</strong></div>
                <div><span>Red</span><strong>{hospitalProfile.network}</strong></div>
              </div>
              <div className="session-welcome-chips">
                {hospitalProfile.specialties.map(item => <span key={item}>{item}</span>)}
              </div>
              <div className="session-welcome-actions">
                <button type="button" className="session-welcome-btn primary" onClick={() => setShowHospitalWelcome(false)}>Ir al sistema</button>
                <button type="button" className="session-welcome-btn secondary" onClick={() => setSelectedNav('Centro de Comando')}>Ver centro de comando</button>
              </div>
            </section>
          </div>
        )}

        {showNotifications && (
          <aside className="notif-panel">
            <div className="notif-head">
              <div>
                <div className="notif-title">Centro de alertas</div>
                <div className="notif-sub">Eventos clinicos y operativos recientes</div>
              </div>
              <button type="button" className="notif-close" onClick={() => setShowNotifications(false)}>Cerrar</button>
            </div>
            <div className="notif-list">
              {notifications.map(item => (
                <div key={item.id} className="notif-item">
                  <div className="notif-tag">{item.type}</div>
                  <div className="notif-item-title">{item.title}</div>
                  <div className="notif-item-text">{item.text}</div>
                </div>
              ))}
            </div>
          </aside>
        )}

        {/* BODY */}
        <div className="ccc-body">
          {isTriageModule ? triageSidebar : systemSidebar}

          <main className="ccc-main">
            {activeMainView}
          </main>
        </div>
      </div>
    </div>
  );
}