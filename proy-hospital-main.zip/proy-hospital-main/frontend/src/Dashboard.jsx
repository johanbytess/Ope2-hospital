﻿import { useCallback, useEffect, useRef, useState } from 'react';
import './dashboard.css';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const DEFAULTS = { c: 4, mu: 4.5, lambda_1: 1.2, lambda_2: 2.4, lambda_3: 4.8 };

const SLIDERS = [
  { key: 'c',        label: 'Medicos de guardia',       min: 1,   max: 12, step: 1,   unit: 'medicos' },
  { key: 'mu',       label: 'Capacidad por medico',     min: 0.5, max: 10, step: 0.5, unit: 'pac/h' },
  { key: 'lambda_1', label: 'Llegadas codigo rojo',     min: 0,   max: 10, step: 0.1, unit: 'pac/h' },
  { key: 'lambda_2', label: 'Llegadas codigo amarillo', min: 0,   max: 15, step: 0.1, unit: 'pac/h' },
  { key: 'lambda_3', label: 'Llegadas codigo verde',    min: 0,   max: 24, step: 0.1, unit: 'pac/h' },
];

const PRESETS = [
  { label: 'Turno estable',      v: { c: 4, mu: 4.5, lambda_1: 1.0, lambda_2: 2.0, lambda_3: 4.0 } },
  { label: 'Pico nocturno',      v: { c: 3, mu: 3.5, lambda_1: 1.4, lambda_2: 3.4, lambda_3: 6.2 } },
  { label: 'Refuerzo operativo', v: { c: 6, mu: 5.0, lambda_1: 1.2, lambda_2: 2.8, lambda_3: 5.0 } },
];

function fmtH(v) {
  return Number(v || 0).toFixed(3) + ' h';
}

function fmtTime(ts) {
  return new Intl.DateTimeFormat('es-PE', {
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    day: '2-digit', month: '2-digit',
  }).format(new Date(ts));
}

function statusOf(rho) {
  if (rho >= 1)    return { label: 'SATURADO', cls: 'st-red' };
  if (rho >= 0.9)  return { label: 'CRITICO',  cls: 'st-red' };
  if (rho >= 0.75) return { label: 'TENSION',  cls: 'st-amber' };
  return               { label: 'ESTABLE',  cls: 'st-green' };
}

export default function Dashboard() {
  const [params, setParams]   = useState(DEFAULTS);
  const [result, setResult]   = useState(null);
  const [history, setHistory] = useState([]);
  const [apiErr, setApiErr]   = useState('');
  const [loading, setLoading] = useState(false);
  const [now, setNow]         = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const loadHistory = useCallback(async () => {
    try {
      const r = await fetch(API + '/escenarios?limit=6');
      if (r.ok) setHistory(await r.json());
    } catch (_) {}
  }, []);

  const simulate = useCallback(async (p, signal) => {
    setLoading(true);
    try {
      const r = await fetch(API + '/simular', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(p),
        signal,
      });
      const data = await r.json();
      if (!r.ok) { setResult(null); setApiErr(data.detail || 'Error al simular.'); }
      else        { setResult(data); setApiErr(''); }
    } catch (e) {
      if (e.name !== 'AbortError') { setResult(null); setApiErr('Sin conexion con la API.'); }
    } finally {
      setLoading(false);
      loadHistory();
    }
  }, [loadHistory]);

  useEffect(() => {
    const ctrl = new AbortController();
    const t = setTimeout(() => simulate(params, ctrl.signal), 420);
    return () => { ctrl.abort(); clearTimeout(t); };
  }, [params, simulate]);

  useEffect(() => { loadHistory(); }, [loadHistory]);

  const demand   = params.lambda_1 + params.lambda_2 + params.lambda_3;
  const capacity = params.c * params.mu;
  const rho      = capacity > 0 ? demand / capacity : 0;
  const st       = statusOf(apiErr ? 1 : (result ? result.rho : rho));

  const wqs = [
    { key: 'wq1', label: 'Rojo',     desc: 'Emergencia vital',      color: '#ef4444', bg: 'var(--red-card)' },
    { key: 'wq2', label: 'Amarillo', desc: 'Urgencia prioritaria',  color: '#f59e0b', bg: 'var(--amber-card)' },
    { key: 'wq3', label: 'Verde',    desc: 'Atencion rutinaria',    color: '#22c55e', bg: 'var(--green-card)' },
  ].map(w => ({ ...w, val: apiErr ? 0 : (result ? (result[w.key] || 0) : 0) }));
  const maxWq = Math.max(...wqs.map(w => w.val), 0.001);

  return (
    <div className="dash">
      <nav className="dash-sidebar">
        <div className="sidebar-brand">
          <span className="brand-dot"></span>
          <span className="brand-name">TRIAGEops</span>
        </div>

        <div className="sidebar-clock">
          <div className="clock-label">Hora del sistema</div>
          <div className="clock-value">{fmtTime(now)}</div>
        </div>

        <div className={'sidebar-status ' + st.cls}>
          <div className="status-dot"></div>
          <span>{st.label}</span>
        </div>

        <div className="sidebar-section-label">PRESETS</div>
        <div className="preset-list">
          {PRESETS.map(p => (
            <button key={p.label} className="preset-btn" onClick={() => setParams(p.v)}>
              {p.label}
            </button>
          ))}
        </div>

        <div className="sidebar-section-label">PARAMETROS</div>
        <div className="slider-stack">
          {SLIDERS.map(s => (
            <div key={s.key} className="slider-row">
              <div className="slider-top">
                <span className="slider-label">{s.label}</span>
                <span className="slider-val">{params[s.key]} {s.unit}</span>
              </div>
              <input
                type="range" min={s.min} max={s.max} step={s.step} value={params[s.key]}
                onChange={e => setParams(p => ({
                  ...p,
                  [s.key]: s.key === 'c' ? parseInt(e.target.value, 10) : parseFloat(e.target.value),
                }))}
              />
            </div>
          ))}
        </div>

        <button className="sim-btn" disabled={loading} onClick={() => simulate(params, undefined)}>
          {loading ? '...' : 'Calcular'}
        </button>
      </nav>

      <main className="dash-main">
        <header className="dash-header">
          <div>
            <p className="header-kicker">Red Hospitalaria Metropolitana</p>
            <h1 className="header-title">Centro de Mando — Guardia de Urgencias</h1>
          </div>
          <div className={'header-badge ' + st.cls}>{st.label}</div>
        </header>

        {apiErr && (
          <div className="alert-bar">
            <strong>Alerta operativa:</strong> {apiErr}
          </div>
        )}

        <div className="kpi-row">
          <div className="kpi kpi-blue">
            <div className="kpi-label">Demanda total</div>
            <div className="kpi-value">{demand.toFixed(1)}</div>
            <div className="kpi-unit">pacientes/h</div>
          </div>
          <div className="kpi kpi-teal">
            <div className="kpi-label">Capacidad instalada</div>
            <div className="kpi-value">{capacity.toFixed(1)}</div>
            <div className="kpi-unit">pacientes/h</div>
          </div>
          <div className={'kpi ' + (rho >= 0.9 ? 'kpi-red' : rho >= 0.75 ? 'kpi-amber' : 'kpi-green')}>
            <div className="kpi-label">Utilizacion (rho)</div>
            <div className="kpi-value">{(apiErr ? 1 : (result ? result.rho : rho)).toFixed(3)}</div>
            <div className="kpi-unit">adimensional</div>
          </div>
          <div className="kpi kpi-purple">
            <div className="kpi-label">Medicos activos</div>
            <div className="kpi-value">{params.c}</div>
            <div className="kpi-unit">en guardia</div>
          </div>
        </div>

        <div className="wait-row">
          {wqs.map(w => (
            <div key={w.key} className="wait-card" style={{ '--accent': w.color }}>
              <div className="wait-header">
                <span className="wait-dot" style={{ background: w.color }}></span>
                <span className="wait-label">{w.label}</span>
              </div>
              <div className="wait-value">{fmtH(w.val)}</div>
              <div className="wait-desc">{w.desc}</div>
              <div className="wait-bar-track">
                <div className="wait-bar-fill" style={{
                  width: Math.max((w.val / maxWq) * 100, 3) + '%',
                  background: w.color,
                }}></div>
              </div>
            </div>
          ))}
        </div>

        <div className="content-row">
          <div className="panel panel-flex">
            <div className="panel-title">Comparacion de tiempos de espera</div>
            {wqs.map(w => (
              <div key={w.key} className="hbar-row">
                <span className="hbar-label">{w.label}</span>
                <div className="hbar-track">
                  <div className="hbar-fill" style={{
                    width: Math.max((w.val / maxWq) * 100, 2) + '%',
                    background: 'linear-gradient(90deg, ' + w.color + '99, ' + w.color + ')',
                  }}></div>
                </div>
                <span className="hbar-val">{fmtH(w.val)}</span>
              </div>
            ))}
          </div>

          <div className="panel panel-flex">
            <div className="panel-title">Diagnostico operativo</div>
            <div className={'diag-badge ' + st.cls}>{st.label}</div>
            {!result && !apiErr && <p className="diag-text">Ajusta los parametros para ver el diagnostico en tiempo real.</p>}
            {apiErr && <p className="diag-text diag-err">La demanda supera capacidad. Activa protocolo de refuerzo y redirige flujo verde.</p>}
            {result && !apiErr && result.rho >= 0.9 && <p className="diag-text diag-warn">Utilizacion critica. Considera apertura de consultorio de apoyo.</p>}
            {result && !apiErr && result.rho < 0.9 && result.wq3 > 0.25 && <p className="diag-text diag-warn">Cola verde en crecimiento. Evalua fast-track para baja complejidad.</p>}
            {result && !apiErr && result.rho < 0.9 && result.wq3 <= 0.25 && <p className="diag-text diag-ok">Sistema estable. Tiempos de espera bajo control en todas las prioridades.</p>}
            <div className="legend-stack">
              <div className="legend-row"><span style={{ background: '#ef4444' }}></span>Rojo — prioridad maxima, atencion inmediata</div>
              <div className="legend-row"><span style={{ background: '#f59e0b' }}></span>Amarillo — urgente, monitoreo cada 15 min</div>
              <div className="legend-row"><span style={{ background: '#22c55e' }}></span>Verde — derivable, senal de congestion</div>
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel-title">Escenarios recientes — SQLite</div>
          {history.length === 0 ? (
            <p className="empty-msg">No hay escenarios guardados todavia.</p>
          ) : (
            <div className="table-wrap">
              <table className="hist-table">
                <thead>
                  <tr>
                    <th>Hora</th><th>Estado</th><th>c</th><th>mu</th>
                    <th>Demanda</th><th>rho</th><th>Rojo</th><th>Amarillo</th><th>Verde</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map(row => {
                    const rs = statusOf(row.rho);
                    return (
                      <tr key={row.id}>
                        <td>{fmtTime(row.created_at)}</td>
                        <td><span className={'tbl-badge ' + rs.cls}>{row.sistema_saturado ? 'SATURADO' : rs.label}</span></td>
                        <td>{row.c}</td>
                        <td>{Number(row.mu).toFixed(1)}</td>
                        <td>{Number(row.lambda_total).toFixed(1)}</td>
                        <td>{Number(row.rho).toFixed(3)}</td>
                        <td>{row.sistema_saturado ? '--' : fmtH(row.wq1)}</td>
                        <td>{row.sistema_saturado ? '--' : fmtH(row.wq2)}</td>
                        <td>{row.sistema_saturado ? '--' : fmtH(row.wq3)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
