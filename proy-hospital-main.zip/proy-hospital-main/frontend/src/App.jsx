import React, { useMemo, useState } from 'react';
import TriageDashboard from './TriageDashboard.jsx';
import './App.css';

const HOSPITAL_PROFILE = {
  name: 'Hospital del Norte',
  short: 'HDN',
  mark: 'HN',
  city: 'El Alto, Bolivia',
  level: 'Tercer Nivel',
  network: 'Red de Salud Corea',
  beds: 220,
  emergency: 'Emergencias 24/7',
  specialties: ['Medicina Interna', 'Cirugia General', 'Pediatria', 'Ginecologia', 'Traumatologia', 'Imagenologia', 'UCI Adultos'],
  services: ['Triage hospitalario', 'Unidad de choque', 'Laboratorio clinico', 'Hospitalizacion critica', 'Quirofanos', 'Banco de sangre'],
  contact: 'Av. Juan Pablo II, Distrito 5, El Alto',
};

const ROLE_DEFINITIONS = [
  { key: 'Administradora', label: 'Administradora', scope: 'Sistema', permissions: 12, description: 'Gestiona cuentas, roles, modulos y configuracion institucional.' },
  { key: 'Supervisora de Triage', label: 'Supervisora de Triage', scope: 'Emergencias', permissions: 9, description: 'Coordina flujos de triage, asignacion de recursos y alertas operativas.' },
  { key: 'Jefa de Enfermeria', label: 'Jefa de Enfermeria', scope: 'Hospitalizacion', permissions: 7, description: 'Controla dotacion por sala, cobertura, incidencias y seguimiento clinico.' },
  { key: 'Medico de Guardia', label: 'Medico de Guardia', scope: 'Asistencial', permissions: 6, description: 'Consulta pacientes, prioridades, camas y evolucion del servicio.' },
];

const DEFAULT_ACCOUNTS = [
  { id: 'acc-001', name: 'Lic. Mariela Quispe', email: 'mquispe@hdn.bo', password: 'hdn123', role: 'Administradora', shift: 'Turno tarde', status: 'Activa' },
  { id: 'acc-002', name: 'Dra. Sonia Choque', email: 'schoque@hdn.bo', password: 'hdn123', role: 'Supervisora de Triage', shift: 'Turno manana', status: 'Activa' },
  { id: 'acc-003', name: 'Lic. Raul Copa', email: 'rcopa@hdn.bo', password: 'hdn123', role: 'Jefa de Enfermeria', shift: 'Turno noche', status: 'Activa' },
  { id: 'acc-004', name: 'Dr. Julio Mamani', email: 'jmamani@hdn.bo', password: 'hdn123', role: 'Medico de Guardia', shift: 'Turno tarde', status: 'Activa' },
];

const EMPTY_LOGIN = { email: 'mquispe@hdn.bo', password: 'hdn123' };

function initials(name) {
  return String(name || '')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0]?.toUpperCase() || '')
    .join('') || 'HD';
}

function WelcomePage({ hospitalProfile, roles, accounts, onLogin }) {
  const [loginForm, setLoginForm] = useState(EMPTY_LOGIN);
  const [message, setMessage] = useState('');

  function updateLogin(key, value) {
    setLoginForm(prev => ({ ...prev, [key]: value }));
  }

  function submitLogin(event) {
    event.preventDefault();
    const found = accounts.find(account => account.email.toLowerCase() === loginForm.email.trim().toLowerCase());
    if (!found || found.password !== loginForm.password) {
      setMessage('Credenciales invalidas. Usa una cuenta registrada del hospital.');
      return;
    }
    setMessage('');
    onLogin(found);
  }

  return (
    <div className="access-root">
      <section className="access-shell">
        <div className="access-brand-panel">
          <div className="access-brand-mark">{hospitalProfile.mark}</div>
          <div className="access-kicker">Sistema hospitalario integral</div>
          <h1 className="access-title">{hospitalProfile.name}</h1>
          <p className="access-text">
            Plataforma de operaciones clinicas y administrativas para el servicio de emergencias,
            hospitalizacion, personal, cuentas y simulacion de triage en {hospitalProfile.city}.
          </p>

          <div className="access-meta-grid">
            <div className="access-meta-card"><span>Nivel</span><strong>{hospitalProfile.level}</strong></div>
            <div className="access-meta-card"><span>Camas</span><strong>{hospitalProfile.beds}</strong></div>
            <div className="access-meta-card"><span>Red</span><strong>{hospitalProfile.network}</strong></div>
            <div className="access-meta-card"><span>Ubicacion</span><strong>{hospitalProfile.contact}</strong></div>
          </div>

          <div className="access-section">
            <div className="access-section-title">Especialidades del hospital</div>
            <div className="access-chip-row">
              {hospitalProfile.specialties.map(item => <span key={item} className="access-chip">{item}</span>)}
            </div>
          </div>

          <div className="access-section">
            <div className="access-section-title">Servicios habilitados</div>
            <div className="access-service-list">
              {hospitalProfile.services.map(item => <div key={item} className="access-service-item">{item}</div>)}
            </div>
          </div>
        </div>

        <div className="access-form-panel">
          <div className="access-form-header">
            <div className="access-form-kicker">Ingreso seguro</div>
            <h2 className="access-form-title">Acceso institucional</h2>
            <p className="access-form-text">
              Inicia sesion con una cuenta existente del hospital. La creacion de nuevos usuarios se realiza unicamente desde el modulo interno de administracion.
            </p>
          </div>

          {message && <div className="access-message">{message}</div>}

          <form className="access-form" onSubmit={submitLogin}>
            <label className="access-field">
              <span>Correo institucional</span>
              <input value={loginForm.email} onChange={e => updateLogin('email', e.target.value)} placeholder="usuario@hdn.bo" />
            </label>

            <label className="access-field">
              <span>Contrasena</span>
              <input type="password" value={loginForm.password} onChange={e => updateLogin('password', e.target.value)} placeholder="Ingresa tu contrasena" />
            </label>

            <div className="access-user-preview">
              <div className="access-user-avatar">{initials(loginForm.email)}</div>
              <div>
                <div className="access-user-name">Accesos activos: {accounts.length}</div>
                <div className="access-user-role">Administracion interna habilitada solo para cuentas autorizadas</div>
              </div>
            </div>

            <button type="submit" className="access-submit">Ingresar al centro de comando</button>
          </form>

          <div className="access-role-preview">
            {roles.map(role => (
              <div key={role.key} className="access-role-card">
                <div className="access-role-top">
                  <strong>{role.label}</strong>
                  <span>{role.permissions} permisos</span>
                </div>
                <div className="access-role-sub">{role.scope}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default function App() {
  const [accounts, setAccounts] = useState(DEFAULT_ACCOUNTS);
  const [session, setSession] = useState(null);
  const hospitalProfile = useMemo(() => HOSPITAL_PROFILE, []);
  const roles = useMemo(() => ROLE_DEFINITIONS, []);

  function createAccount(payload) {
    const created = {
      id: `acc-${Date.now()}`,
      ...payload,
    };
    setAccounts(prev => [created, ...prev]);
    return created;
  }

  function updateAccountRole(accountId, role) {
    setAccounts(prev => prev.map(account => account.id === accountId ? { ...account, role } : account));
    setSession(prev => prev && prev.id === accountId ? { ...prev, role } : prev);
  }

  function login(account) {
    setSession(account);
  }

  function logout() {
    setSession(null);
  }

  if (!session) {
    return (
      <WelcomePage
        hospitalProfile={hospitalProfile}
        roles={roles}
        accounts={accounts}
        onLogin={login}
      />
    );
  }

  return (
    <TriageDashboard
      hospitalProfile={hospitalProfile}
      currentUser={session}
      accounts={accounts}
      roles={roles}
      onCreateAccount={createAccount}
      onUpdateAccountRole={updateAccountRole}
      onLogout={logout}
    />
  );
}