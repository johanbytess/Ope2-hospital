# Publicar el sistema en la web

Este proyecto tiene dos partes:

- `frontend/`: React + Vite
- `backend/`: FastAPI + SQLite

La forma mas simple de publicarlo es separar frontend y backend.

## Opcion recomendada

- Frontend en Vercel
- Backend en Render

## 1. Publicar el backend en Render

1. Sube el proyecto a GitHub.
2. En Render crea un nuevo `Web Service` conectado a tu repositorio.
3. Usa estos valores:

   - Root Directory: `backend`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`

4. Agrega esta variable de entorno en Render:

   - `FRONTEND_ORIGINS=https://tu-frontend.vercel.app`

5. Cuando Render termine, te dara una URL parecida a:

   - `https://tu-backend.onrender.com`

6. Prueba en el navegador:

   - `https://tu-backend.onrender.com/`

## 2. Publicar el frontend en Vercel

1. En Vercel crea un nuevo proyecto conectado al mismo repositorio.
2. Configura:

   - Root Directory: `frontend`
   - Build Command: `npm run build`
   - Output Directory: `dist`

3. Agrega esta variable de entorno en Vercel:

   - `VITE_API_URL=https://tu-backend.onrender.com`

4. Despliega y Vercel te dara una URL como:

   - `https://tu-frontend.vercel.app`

## 3. Ajuste final

Despues de tener la URL del frontend, vuelve a Render y actualiza:

- `FRONTEND_ORIGINS=https://tu-frontend.vercel.app`

Luego redeploy del backend.

## Notas importantes

- Hoy las cuentas y varios datos siguen en memoria del frontend. Si el usuario recarga la pagina o si el frontend se vuelve a desplegar, esos cambios no se guardan permanentemente.
- La base SQLite del backend puede funcionar para demos, pero en hosting gratuito puede perder datos o no ser ideal para varios usuarios. Para produccion real conviene PostgreSQL.
- Si quieres una sola URL y un solo despliegue, se puede unificar frontend y backend en un solo servicio, pero requiere un ajuste adicional para servir los archivos estaticos desde FastAPI.

## Comandos locales utiles

Frontend:

```bash
npm run build
```

Backend:

```bash
uvicorn main:app --reload
```